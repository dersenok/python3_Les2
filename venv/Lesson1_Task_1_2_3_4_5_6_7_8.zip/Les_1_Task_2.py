# 2. По введенным пользователем координатам двух
# точек вывести уравнение прямой вида y = kx + b,
# проходящей через эти точки.

# https://drive.google.com/file/d/1qX2Olvp25iM14p1tzWp6y3DTM4PZjLRk/view?usp=sharing

print("Координаты точки A(x1;y1):")
x1 = float(input("\tx1 = "))
y1 = float(input("\ty1 = "))

print("Координаты точки B(x2;y2):")
x2 = float(input("\tx2 = "))
y2 = float(input("\ty2 = "))

print("Уравнение прямой, проходящей через эти точки:")
k = (y1 - y2) / (x1 - x2)
b = y2 - k * x2
print(" y = %.2f*x + %.2f" % (k, b))

